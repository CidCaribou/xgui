async function injectLocalScript(tabId) {
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      world: "MAIN",
      files: ["x-gui.js"]
    });
  } catch (e) {
    console.error("[X-GUI extension] inject failed", e);
  }
}

chrome.action.onClicked.addListener((tab) => {
  if (tab.id) {
    injectLocalScript(tab.id);
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (
    changeInfo.status === "complete" &&
    tab.url?.endsWith("?x-gui")
  ) {
    injectLocalScript(tabId);
  }
});
